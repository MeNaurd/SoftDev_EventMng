# Changelog R.E.P.O Save Editor.

## Version 3.0.0 (2025-04-27)

### Major Improvements.
- **Fixed save corruption issue**: Saves are now processed correctly and are no longer corrupted during the save operation.
- **Improved user interface**: Redesigned interface for better usability and clarity.
- **Multi-language support**: Added support for multiple languages. 
